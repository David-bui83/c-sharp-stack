namespace phone
{
    public interface IRingable
    {
        string Ring();
        string Unlocked();
    }
}