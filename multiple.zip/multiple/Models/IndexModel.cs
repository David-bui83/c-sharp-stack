using System.ComponentModel.DataAnnotations;
namespace multiple.Models
{
    public class IndexModel
    {
        public Registration NewReg {get;set;}
        public Login NewLog{get;set;}
    }
}