using System;
using System.ComponentModel.DataAnnotations;
namespace bank.Models
{
    public class Login
    {
        public string LoginEmail {get;set;}

        public string LoginPassword {get;set;}

    }
}